import { useEffect, useState } from "react";
import type {
  AlertItem,
  HistoryPoint,
  LiveReading,
  RelayEvent,
  RelayStatus,
  TransformerDevice,
} from "@/lib/types";

/**
 * MOCK DATA LAYER
 * ----------------
 * Everything in this file is fake data generated in the browser so the UI
 * is fully functional without any backend connected yet.
 *
 * To connect real hardware, replace the bodies of these hooks with:
 *   - Blynk: fetch(`https://blynk.cloud/external/api/get?token=...&v0`)
 *   - Firebase: onSnapshot(doc(db, "transformers", id), ...)
 *
 * Keep the return shape the same and every page in src/pages keeps working.
 */

const DEVICE: TransformerDevice = {
  id: "TR-0042",
  name: "Distribution Transformer 42",
  location: "Sector 4B, Pimpri-Chinchwad",
  lat: 18.6298,
  lng: 73.8131,
  status: "warning",
  online: true,
  lastUpdated: new Date().toISOString(),
};

function randomWalk(base: number, spread: number) {
  return +(base + (Math.random() - 0.5) * spread).toFixed(1);
}

export function useLiveReading(): LiveReading {
  const [reading, setReading] = useState<LiveReading>({
    voltage: 231,
    current: 42,
    temperature: 58,
    humidity: 46,
    timestamp: new Date().toISOString(),
  });

  useEffect(() => {
    const id = setInterval(() => {
      setReading((prev) => ({
        voltage: randomWalk(prev.voltage, 2),
        current: randomWalk(prev.current, 3),
        temperature: Math.min(90, randomWalk(prev.temperature, 1.5)),
        humidity: randomWalk(prev.humidity, 2),
        timestamp: new Date().toISOString(),
      }));
    }, 2000);
    return () => clearInterval(id);
  }, []);

  return reading;
}

export function useDevice(): TransformerDevice {
  return DEVICE;
}

export function useRelayStatus(): RelayStatus {
  return {
    state: "closed",
    autoTripEnabled: true,
    lastTripReason: "Over-temperature (92C)",
    lastTripAt: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    thresholds: {
      maxTemperature: 90,
      maxCurrent: 100,
      maxVoltage: 260,
    },
  };
}

export function useRelayEvents(): RelayEvent[] {
  return [
    {
      id: "evt-1",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
      cause: "Over-temperature (92C)",
      durationMinutes: 14,
    },
    {
      id: "evt-2",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
      cause: "Over-current (108A)",
      durationMinutes: 6,
    },
    {
      id: "evt-3",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 11).toISOString(),
      cause: "Manual trip (maintenance)",
      durationMinutes: 120,
    },
  ];
}

export function useAlerts(): AlertItem[] {
  return [
    {
      id: "al-1",
      severity: "critical",
      title: "High temperature",
      description: "Oil temperature reached 63C, above the 60C warning threshold.",
      timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
      status: "active",
    },
    {
      id: "al-2",
      severity: "warning",
      title: "Current overload",
      description: "Load current at 96% of rated capacity.",
      timestamp: new Date(Date.now() - 1000 * 60 * 55).toISOString(),
      status: "active",
    },
    {
      id: "al-3",
      severity: "warning",
      title: "High humidity",
      description: "Enclosure humidity at 78%, above nominal range.",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
      status: "acknowledged",
    },
    {
      id: "al-4",
      severity: "info",
      title: "Device reconnected",
      description: "ESP32 node came back online after a 4 minute gap.",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 9).toISOString(),
      status: "resolved",
    },
    {
      id: "al-5",
      severity: "critical",
      title: "Relay tripped",
      description: "Automatic trip triggered by over-temperature protection.",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
      status: "resolved",
    },
  ];
}

export function useHistory(range: "day" | "week" | "month" | "year"): HistoryPoint[] {
  const points = range === "day" ? 24 : range === "week" ? 7 : range === "month" ? 30 : 12;
  const labelFor = (i: number) => {
    if (range === "day") return `${i}:00`;
    if (range === "week") return `Day ${i + 1}`;
    if (range === "month") return `Day ${i + 1}`;
    return `Month ${i + 1}`;
  };

  return Array.from({ length: points }, (_, i) => ({
    time: labelFor(i),
    voltage: randomWalk(230, 6),
    current: randomWalk(45, 10),
    temperature: randomWalk(55, 12),
    humidity: randomWalk(48, 10),
  }));
}
