import { Link, useNavigate } from "react-router-dom";
import { Zap } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface px-md">
      <div className="w-full max-w-sm">
        <div className="flex items-center justify-center gap-2 mb-lg">
          <Zap size={22} className="text-primary" />
          <span className="text-headline-md text-on-surface">Transformer Monitor</span>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            navigate("/");
          }}
          className="rounded border border-outline-variant bg-surface-container-lowest p-lg flex flex-col gap-md"
        >
          <div>
            <label className="text-body-sm text-on-surface-variant">Email</label>
            <input
              type="email"
              required
              placeholder="you@utility.com"
              className="mt-1 w-full h-10 rounded border border-outline-variant bg-surface-container-lowest px-sm text-body-md text-on-surface focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
          <div>
            <label className="text-body-sm text-on-surface-variant">Password</label>
            <input
              type="password"
              required
              placeholder="••••••••"
              className="mt-1 w-full h-10 rounded border border-outline-variant bg-surface-container-lowest px-sm text-body-md text-on-surface focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
          <button
            type="submit"
            className="h-10 rounded bg-primary text-on-primary text-body-md font-medium hover:opacity-90"
          >
            Sign in
          </button>
          <p className="text-body-sm text-on-surface-variant text-center">
            No account?{" "}
            <Link to="/sign-up" className="text-primary hover:underline">
              Create one
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
